<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Vacation</title>
    <link rel="stylesheet" href="{{asset('maintenance.css')}}" />
  </head>
  <body>
    <div class="maintenance">
      <img src="{{asset('close/vacaation.png')}}" alt="" />
      <p>We're taking a short vacation <br> We will be back soon</p>
    </div>
  </body>
</html>
