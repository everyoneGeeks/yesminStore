<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class wishListController extends Controller
{
    //
}
