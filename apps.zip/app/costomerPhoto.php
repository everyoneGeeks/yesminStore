<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class costomerPhoto extends Model
{
    protected $table="costomerPhoto";
    public $timestamps = false;
}
