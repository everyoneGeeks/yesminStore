<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class websiteSetting extends Model
{
    protected $table="website_settings";
    public $timestamps = false;


}
