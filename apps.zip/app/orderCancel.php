<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orderCancel extends Model
{
  public $timestamps = false;
  public $table="order_cancel";
}
