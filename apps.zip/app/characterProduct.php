<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class characterProduct extends Model
{
    protected $table="character_product";
    public $timestamps = false;
}
