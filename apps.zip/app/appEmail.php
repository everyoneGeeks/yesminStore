<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class appEmail extends Model
{
    protected $table="app_emails";
    public $timestamps = false;
}
