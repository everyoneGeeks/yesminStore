<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\appSetting;
use Carbon\Carbon;
/*
|--------------------------------------------------------------------------
| appSettingController
|--------------------------------------------------------------------------
| this will handle all appSetting part (CRUD) 
|
*/
/***
 *                        _____      _   _   _             
 *                       / ____|    | | | | (_)            
 *       __ _ _ __  _ __| (___   ___| |_| |_ _ _ __   __ _ 
 *      / _` | '_ \| '_ \\___ \ / _ \ __| __| | '_ \ / _` |
 *     | (_| | |_) | |_) |___) |  __/ |_| |_| | | | | (_| |
 *      \__,_| .__/| .__/_____/ \___|\__|\__|_|_| |_|\__, |
 *           | |   | |                                __/ |
 *           |_|   |_|                               |___/ 
 */
class appSettingController extends Controller
{
    /**  
    * show  form edit  of  appSetting By id 
    * -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    * @author ಠ_ಠ Abdelrahman Mohamed <abdomohamed00001@gmail.com>
    */
    public function formEdit(){
        $appSetting=appSetting::where('id',1)->first();
        
        return view('pages.appSetting.edit',compact('appSetting'));
    }    

    /**  
    * save edit  of  appSetting By id 
    * -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    * @author ಠ_ಠ Abdelrahman Mohamed <abdomohamed00001@gmail.com>
    */
    public function submitEdit(Request $request){


        $Notification=appSetting::where('id',1)->first();
        $Notification->aboutus=$request->about_us_ar;
        $Notification->aboutus=$request->about_us_en;
        $Notification->contactus=$request->policy_term_ar;
        $Notification->delivery_returns=$request->policy_term_en;
        $Notification->terms_policy_ar=$request->point_for_new_order;
        $Notification->aboutus_ar=$request->point_for_rating;
        $Notification->contactus_ar=$request->minimum_to_accept_order;
        $Notification->delivery_returns_ar=$request->fees;
        $Notification->delivery_info=$request->point_for_rating;
        $Notification->delivery_info_ar=$request->minimum_to_accept_order;
        $Notification->save();

        \Notify::success('تم تعديل الصفحات    بنجاح', ' تعديل الصفحات ');
        return redirect()->back();
    }  





    /**  
    * show  form edit  of  appSetting By id 
    * -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    * @author ಠ_ಠ Abdelrahman Mohamed <abdomohamed00001@gmail.com>
    */
    public function formEditLinks(){
        $appSetting=appSetting::where('id',1)->first();
        
        return view('pages.appSetting.Links',compact('appSetting'));
    }    

    /**  
    * save edit  of  appSetting By id 
    * -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    * @author ಠ_ಠ Abdelrahman Mohamed <abdomohamed00001@gmail.com>
    */
    public function submitEditLinks(Request $request){


        $Notification=appSetting::where('id',1)->first();
        $Notification->facebook=$request->facebook;
        $Notification->youTube=$request->youTube;
        $Notification->instagram=$request->instagram;
        $Notification->pinterest=$request->pinterest;
        $Notification->save();

        \Notify::success('تم  تعديل مواقع التواصل  بنجاح', ' مواقع التواصل تعديل  ');
        return redirect()->back();
    }  








    /**  
    * show  form edit  of  appSetting By id 
    * -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    * @author ಠ_ಠ Abdelrahman Mohamed <abdomohamed00001@gmail.com>
    */
    public function formEditClose(){
        $appSetting=appSetting::where('id',1)->first();
        
        return view('pages.appSetting.Close',compact('appSetting'));
    }    

    /**  
    * save edit  of  appSetting By id 
    * -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    * @author ಠ_ಠ Abdelrahman Mohamed <abdomohamed00001@gmail.com>
    */
    public function submitEditClose(Request $request){


        $Notification=appSetting::where('id',1)->first();
        $Notification->Close=$request->Close;

        $Notification->save();
        if($Notification->Close == 0){
            \Notify::success('تم  غلق  الموقع     بنجاح', '  تم غلق الموقع  ');
        }else{
            \Notify::success('تم  فتح   الموقع     بنجاح', '  تم فتح  الموقع  ');
        }

        return redirect()->back();
    }  






  

}
