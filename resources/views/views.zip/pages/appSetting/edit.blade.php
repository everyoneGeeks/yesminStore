@extends('layoutDashboard.app',['title'=>' الاعدادات'])

@section('content')
@component('components.error',['errors'=>$errors ?? NULL]) @endcomponent
@component('components.panel',['subTitle'=>' ادارة الاعدادات'])
<div class="container-fluid">
        <div class="row">
          <div class="col-md-12 ">

          <form role="form" action="{{route('appSetting.edit')}}" method="post" enctype="multipart/form-data">
          @csrf
                <div class="card-body">
                  <div class="form-group">
                    <label for="InputNameAr">  عن التطبيق بالعربي</label>
            
                    <textarea type="text" id="editor1" class="form-control ckeditor"   name="about_us_ar">
                    {{$appSetting->aboutus_ar}}
                    </textarea>
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">  عن التطبيق بالانجليزي</label>
                    <textarea type="text" id="editor2" class="form-control ckeditor"  name="about_us_en">
                    {{$appSetting->aboutus}}
                    </textarea>
                  </div>

                  <div class="form-group">
                    <label for="InputNameAr">  سياسة التطبيق بالعربي</label>
                    <textarea type="text"  id="editor3" class="form-control ckeditor "  name="policy_term_ar">
                    {{$appSetting->policy_term_ar}}
                    </textarea>
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">  سياسة التطبيق بالانجليزي </label>
                    <textarea type="text"  id="editor4" class="form-control ckeditor "  name="policy_term_en">
                    {{$appSetting->policy_term_en}}

                    </textarea>

                  </div>



                  <div class="form-group">
                    <label for="InputNameAr">  سياسة التطبيق بالعربي</label>
                    <textarea type="text"  id="editor3" class="form-control ckeditor "  name="delivery_returns">
                    {{$appSetting->delivery_returns}}
                    </textarea>
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">  سياسة التطبيق بالانجليزي </label>
                    <textarea type="text"  id="editor4" class="form-control ckeditor "  name="delivery_returns_ar">
                    {{$appSetting->delivery_returns_ar}}

                    </textarea>

                  </div>






                  <div class="form-group">
                    <label for="InputNameAr">    معلومات عن التوصيل بالانجليزي </label>
                    <textarea type="text"  id="editor3" class="form-control ckeditor "  name="delivery_info">
                    {{$appSetting->delivery_info}}
                    </textarea>
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">   معلومات عن التوصيل بالعربي   </label>
                    <textarea type="text"  id="editor4" class="form-control ckeditor "  name="delivery_info_ar">
                    {{$appSetting->delivery_info_ar}}

                    </textarea>

                  </div>









                  <div class="form-group">
                    <label for="InputNameAr">  سياسة التطبيق بالعربي</label>
                    <textarea type="text"  id="editor3" class="form-control ckeditor "  name="delivery_returns">
                    {{$appSetting->contactus}}
                    </textarea>
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">  سياسة التطبيق بالانجليزي </label>
                    <textarea type="text"  id="editor4" class="form-control ckeditor "  name="delivery_returns_ar">
                    {{$appSetting->contactus_ar}}

                    </textarea>

                  </div>





                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">ارسال</button>
                </div>
              </form>
              
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          
      @endcomponent



 @endsection

 @section('javascript')
 <script src="{{asset('/plugins/ckeditor/ckeditor.js')}}"></script>

 <script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor1'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;
      



      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor2'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;
      



      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor3'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;
      




      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor4'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;
      



      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor5'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;
      




      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor6'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;



      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor7'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;




      $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    ClassicEditor
      .create(document.querySelector('#editor8'))
      .then(function (editor) {
        // The editor instance
      })
      .catch(function (error) {
        console.error(error)
      });
       
      }) ;
      

    </script>
 @endsection