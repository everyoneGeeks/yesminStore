@extends('layoutDashboard.app',['title'=>' مواقع التواصل الاجتماعي '])
@section('style')
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

@endsection
@section('content')
@component('components.error',['errors'=>$errors ?? NULL]) @endcomponent
@component('components.panel',['subTitle'=>' مواقع التواصل الاجتماعي '])
<div class="container-fluid">
        <div class="row">
          <div class="col-md-12 ">

          <form role="form" action="{{route('appSetting.links.edit')}}" method="post" enctype="multipart/form-data">
          @csrf
                <div class="card-body">
                  
                <div class="checkbox">
  <label>
    <input type="checkbox" data-toggle="toggle">
   @if($appSetting->close == 0)

      تم غلق الويب سايت 
   @else 

تم فتح الويب سايت 

   @endif
  </label>
</div>


                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">ارسال</button>
                </div>
              </form>
              
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          
      @endcomponent



 @endsection



 @section('javascript')
 <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
 @endsection