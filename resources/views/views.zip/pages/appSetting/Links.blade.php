@extends('layoutDashboard.app',['title'=>' مواقع التواصل الاجتماعي '])
@section('content')
@component('components.error',['errors'=>$errors ?? NULL]) @endcomponent
@component('components.panel',['subTitle'=>' مواقع التواصل الاجتماعي '])
<div class="container-fluid">
        <div class="row">
          <div class="col-md-12 ">

          <form role="form" action="{{route('appSetting.links.edit')}}" method="post" enctype="multipart/form-data">
          @csrf
                <div class="card-body">
                  <div class="form-group">
                    <label for="InputNameAr">  facebooks </label>
                    <input type="text" class="form-control" id="InputNameAr" value="{{$appSetting->facebook}}" name="facebook">
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">  youTube  </label>
                    <input type="text" class="form-control" id="InputNameEn" value=" {{$appSetting->youTube}}" name="youTube">
                  </div>

                  <div class="form-group">
                    <label for="InputNameAr">  instagram </label>
                    <input type="text" class="form-control" id="InputNameAr" value="{{$appSetting->instagram}}" name="instagram">
                  </div>
                  <div class="form-group">
                    <label for="InputNameEn">  pinterest  </label>
                    <input type="text" class="form-control" id="InputNameEn" value=" {{$appSetting->pinterest}}" name="pinterest">
                  </div>



                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">ارسال</button>
                </div>
              </form>
              
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          
      @endcomponent



 @endsection