<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class costomerRate extends Model
{
    protected $table="costomerRate";
    public $timestamps = false;
}
