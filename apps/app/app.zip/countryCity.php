<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class countryCity extends Model
{
    protected $table="country_city";
    public $timestamps = false;


}
