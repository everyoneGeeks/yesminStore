<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class party_theme_product extends Model
{
    protected $table="party_theme_product";
    public $timestamps = false;

}
