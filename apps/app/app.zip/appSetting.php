<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class appSetting extends Model
{
    protected $table="website_settings";
    public $timestamps = false;
}
