<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reservation_service_list extends Model
{
    //
}
