<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class productImage extends Model
{
    protected $table="image_products";
    public $timestamps = false;
}
