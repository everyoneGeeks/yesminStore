<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bankAccounts extends Model
{
    protected $table="bank_accounts";
    public $timestamps = false;
}
