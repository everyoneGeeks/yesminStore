<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class appPhone extends Model
{
    protected $table="app_phones";
    public $timestamps = false;
}
